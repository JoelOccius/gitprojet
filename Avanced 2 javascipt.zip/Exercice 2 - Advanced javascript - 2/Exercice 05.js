/*⚠️ NE MODIFIEZ PAS LE NOM DES DÉCLARATIONS ⚠️*/
/*5️⃣ EXERCICE 05 5️⃣*/



function isPositive(num) {
   // The function receives an integer. Returns as a result a string that indicates whether the number
   // is positive or negative.
   // If the number is positive ---> "It is positive."
   // If the number is negative ---> "It is negative."
   // If the number is 0, return false.
   // Your code:
   if(num == "positive"){
     return "it is positive"
   }else if("is negative"){
      return "it is negative"
   }else("is 0 "){
      return "false"
   }
      
   
};

function addSymbolExclamation(str) {
   // Add an exclamation mark to the end of the string "str" ​​and return it
   // Example: "hello world" ---> "hello world!"
   // Your code:
   return str +'!'
}
console.log(addSymbolExclamation("Hello world"))

function combineNames(firstName, LastName) {
   // Returns "first name" and "last name" combined in the same string but separated by a space.
   // Example: ("Webster", "Fever") ---> "Fever Webster"
   // Your code:
   return firstName + "JOEL"
}
console.log(combineNames("OCCIUS"))

function getGreeting(name) {
   // Take the string "name" and concatenate another string into the string so that it takes the following form:
   // Example: "Martin" ---> "Hello Martin!"
   // Your code:
   return name + "Adline" + "!"
}
console.log(getGreeting("Hello"))

function getRectangleArea(Height, width) {
   // Return the area of ​​a rectangle having its height and width.
   // Your code:
   return a * b
}
console.log(getRectangleArea(4 , 8))

function returnPerimeter(side) {
  // The function receives as an argument the measurement of one side of a square.
   // You must return its perimeter.
   // Your code:
   return side * 4
}
console.log(returnPerimeter(4 , 4))

function trianglearea(base, height, ) {
    // Calculates the area of ​​a triangle and returns the result.
   // Your code:
   return (base * height) / 2;
}
console.log(trianglearea(30 , 15));

function convertEurosToDollars(euros) {
   // Suppose that 1 euro is equivalent to 1.20 dollars.
   // You must calculate the value received as an argument, converting it to dollars.
   // Your code:
   const exchangeRate = 1.20;
   const dollars = euros * exchangeRate;
   return dollars;
}
const eurosValue = 80;
const dollarsValue = convertEurosToDollars(eurosValue);

console.log(eurosValue + "euros is equivalent to" + dollarsValue + "dollars");

function isVowel(letter) {
   // Write a function that takes a letter and, if it is a vowel, displays the message “It is a vowel.”
   // If the user enters a string of more than one character you must return the message: "Incorrect data".
   // If it is not a vowel, it must also return "Incorrect data".
   // Your code:
   if(letter == "a" || letter == "e" || letter == "i" ||
    letter == "o" || letter == "u" || letter == "y"){
      return "it is vowel"
    }else{
      return "incorrect"
    }
}
console.log(isVowel)

