/*⚠️ NE MODIFIEZ PAS LE NOM DES DÉCLARATIONS ⚠️*/

/*2️⃣ EXERCICE 2️⃣*/

function returnString(string) {
   // Must return a string.
   // Your code:
   return string;
}
console.log(returnString('webster'));

// ⛔️ "X" and "Y" are numbers.

function sum(x, y) {
   // Return the result of their sum.
   // Your code:
   let result = x + y
   return result;
}
console.log(sum(8 , 2))

function sub(x, y) {
   // Return the result of their subtraction.
   // Your code:
   let result = x - y;
   return result;
}
console.log(sub(20 , 3));

function divide(x, y) {
   // Return the result of your division.
   // Your code:
   let result = x / y;
   return result;
}
console.log(divide(1500 , 7));

function multiply(x, y) {
   // Return the result of your multiplication.
   // Your code: 
   let result = x * y;
   return result;
}
console.log(multiply(89 , 15));

function getRest(x, y) {
   //Find the remainder of the division of "x" by "y".
   // Your code:
   let result = x - y;
   return result;
}
console.log(getRest(2000 , 2));

 