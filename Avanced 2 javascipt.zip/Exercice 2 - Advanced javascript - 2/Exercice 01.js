/*⚠️ NE MODIFIEZ PAS LE NOM DES DÉCLARATIONS ⚠️*/
/*1️⃣ EXERCICE 01 1️⃣*/

// Dans les exercices suivants vous devrez remplacer la valeur nulle
// pour le correspondant.

// Create a variable of type string.
const newString = 'webster';
console.log(newString)

// Create a variable of type number.
const newNumero = 8;
console.log(newNumero)

// Create a variable of type boolean.
const newBoolean = false;
console.log(newBoolean)

// Solve the following math problem.
const newRest = 10 - 7 === 3;
console.log(newRest)

// Solve the following math problem.
const multiply = 10 * 4 === 40;
console.log(multiply)

// Solve the following math problem.
const newModule = 21 % 5 === 1;
console.log(newModule)


