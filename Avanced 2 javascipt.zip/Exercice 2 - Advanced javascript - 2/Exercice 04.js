/*⚠️ NE MODIFIEZ PAS LE NOM DES DÉCLARATIONS ⚠️*/
/*4️⃣ EXERCICE 04 4️⃣*/

// ⛔️ Remember that you must use the global object "Math".

function square(num) {
   // Returns the value of "num" squared (Renvoie la valeur de "num" au carré).
   // YOur code:
   return num **2
}
console.log(square(5))

function raiseToCube(num) {
   // Returns the value of "num" cubed.
   // Your code:
   return num **3
}
console.log(raiseToCube(3))

function raise(num, exponent) {
   // Returns the value of "num" raised to the exponent "exponent".
   // Your code:.
   return 5 **6
}
console.log(raise(5 , 6))

function roundNumber(num) {
   return Math.round(num)
}
console.log(roundNumber(6.80))



function randomnumber() {
   // Generate a random number between 0 and 10 and return it.
   // Your code :
   return Math.random()
}
console.log(randomnumber(0))


